package remote

import "fmt"

const (
	debuggerEventBaseKey = "remote-config"

	// defaultMaxGroup represents the maximum value for a rollout group,
	// effectively making the value to be in range of 1-100 (inclusive) to reflect percentage-based groups.
	defaultMaxGroup                uint32 = 100
	logPrefix                             = "[Remote Config]"
	messageNamespace                      = "nordvpn-linux"
	rcFailure                             = "failure"
	rcSuccess                             = "success"
	partialRolloutPerformedFailure        = false
	partialRolloutPerformedSuccess        = true
	rolloutNo                             = "no"
	rolloutYes                            = "yes"
	subscope                              = "linux-rc"
)

// EventType defines the type of remote config analytics event.
type EventType int

const (
	Download EventType = iota
	DownloadSuccess
	DownloadFailure
	LocalUse
	JSONParseSuccess
	JSONParseFailure
	Rollout
)

func (e EventType) String() string {
	switch e {
	case Download:
		return "rc_download"
	case DownloadSuccess:
		return "rc_download_success"
	case DownloadFailure:
		return "rc_download_failure"
	case LocalUse:
		return "rc_local_use"
	case JSONParseSuccess:
		return "rc_json_parse_success"
	case JSONParseFailure:
		return "rc_json_parse_failure"
	case Rollout:
		return "rc_rollout"
	default:
		return fmt.Sprintf("%d", int(e))
	}
}

const (
	FeatureMain     = "nordvpn"
	FeatureLibtelio = "libtelio"
	FeatureMeshnet  = "meshnet"
)

const (
	ClientCli = "cli"
)
